/*
Name: Gunnar Hovik
Date: 13 Feburary 2023
Assignment: 3
This class is meant to test the Trie class. It takes two arguments, both filenames.
The first is a list of words to add to a test Trie.
The second is a list of words to search the trie for.
*/
#include <iostream>
#include <fstream>
#include "Trie.h"
using namespace std;

int main(int argc, char *argv[]){
    //Check Args
    if(argc != 3){
        cout << "Incorrect number of arguments given." << endl;
        return 0;
    }
    //Setup vars
    ifstream wordsFile;
    ifstream qFile;
    wordsFile.open(argv[1]);
    qFile.open(argv[2]);

    //Check files
    if(!wordsFile.good()){
        cout << "First file not found!" << endl;
        return 0;
    }
    if(!qFile.good()){
        cout << "Second file not found!" << endl;
        return 0;
    }

    //Setup Trie
    Trie words;
    while(wordsFile){
        string word;
        wordsFile >> word;
        //sometime it picks up empty chars
        if(word.length() == 0)
            continue;
        words.addAWord(word);
    }
    
    //Testing File
    while(qFile){
        string query;
        qFile >> query;
        //sometime it picks up empty chars
        if(query.length() == 0)
            continue;
        cout << "Testing " << query << ":" << endl;
        bool found;
        found = words.isAWord(query);
        if(found)
            cout << "Found" << endl;
        else
            cout << "Not Found" << endl;

        vector<string> v;
        v = words.allWordsBeginningWithPrefix(query);
        for(string s : v)
            cout << s << endl;
    }

    cout << endl;
    //Testing Assignemnt Operator
    Trie original;
    original.addAWord("a");
    original.addAWord("apple");
    original.addAWord("ants");
    Trie copy = original;
    vector<string> wordsInO = original.allWordsBeginningWithPrefix("");
    vector<string> wordsInC = copy.allWordsBeginningWithPrefix("");
    for(string s : wordsInO){
        if(!copy.isAWord(s)){
            cout << "Failed Assignment" << endl;
            return 0;
        }
    }
    cout << "Passed Assignment Test" << endl;

    //Testing Copy Constructor
    Trie copyConstructed(original);
    for(string s : wordsInO){
        if(!copyConstructed.isAWord(s)){
            cout << "Failed Copy Constructor Copying" << endl;
            return 0;
        }
    }
    cout << "Passed Copy Constructor Copying Test" << endl;

    //Make sure they are different
    original.addAWord("new");
    if(copyConstructed.isAWord("new")){
        cout << "Failed Copy Constructor Indpendence Test" << endl;
        return 0;
    }
    cout << "Passed Copy Constructor Independence Test" << endl;
    if(copy.isAWord("new")){
        cout << "Failed Assisngment Independence Test" << endl;
        return 0;
    }
    cout << "Passed Assignment Independence Test" << endl;
}
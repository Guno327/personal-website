#include "hpdf.h"
/*This is header file for a wrapper class for the HaruPDF library*/
class HaruPDF{
    HPDF_Doc  pdf;
    HPDF_Page page;
    HPDF_Font font;
    public:
    HaruPDF();
    void SetRotationMatrix(double a, double b, double c, double d, double x,double y);
    void AddChar(char c);
    void CreateFile(char name[]);
};
#include "HaruPDF.h"
/*Class that implements the HaruPDF header file and as such is a
    wrapper class for the HaruPDF library.*/

/*Constructor, sets up all the pdf things.*/
HaruPDF::HaruPDF(){
    pdf = HPDF_New (NULL, NULL);
    page = HPDF_AddPage (pdf);
    HPDF_Page_SetSize (page, HPDF_PAGE_SIZE_A5, HPDF_PAGE_PORTRAIT);
    HPDF_Page_BeginText (page);
    font = HPDF_GetFont (pdf, "Courier-Bold", NULL);
    HPDF_Page_SetTextLeading (page, 20);
    HPDF_Page_SetGrayStroke (page, 0);
    HPDF_Page_SetFontAndSize (page, font, 30);
}

/*Allows us to set the location and rotation of new text,
    side note I have no idea how the SetTextMatrix works
    and you shouldn't have to either, as such I have copied
    the names of the method args.*/
void HaruPDF::SetRotationMatrix(double a, double b, double c, double d, double x, double y){
    HPDF_Page_SetTextMatrix(page, a, b, c, d, x, y);
}

/*Adds one character to the PDF*/
void HaruPDF::AddChar(char c){
    char buf[2] {c,0};
    HPDF_Page_ShowText (page, buf);
}

/*Outputs a PDF file of the current document*/
void HaruPDF::CreateFile(char name[]){
    HPDF_Page_EndText (page);
    HPDF_SaveToFile (pdf, name);
    HPDF_Free (pdf);
}
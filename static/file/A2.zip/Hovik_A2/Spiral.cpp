/*Class that implements the Spiral header file and as such
    is a mathmatical class that calculates a spiral*/
#include "Spiral.h"
#include <math.h>

/*Constructor, sets up all the starting parameters for the spiral
    to be created.*/
Spiral::Spiral(double centerX, double centerY, double startAngle, double loopScale){
    this->centerX = centerX;
    this->centerY = centerY;
    if(startAngle < 0)
        startAngle = (-1) * startAngle;
    angle = startAngle;
    scale = loopScale;
}

/*Converts from a Spiral angle to a Mathmatical angle.
    Spiral angle increments CW, while 
    mathmatical angle increments CCW. Spiral angles also
    have 0 deg at north, while mathmatical angles have it at east*/
double Spiral::ConvertAngle(double angle){
    //Find how many times we have gone around the circle
    int numRound = angle / 360;
    //Find how far we are on this rotation
    double remainder = angle - (360*numRound);
    //Convert current rotation to math angles
    double converted = 360 - remainder + 90;
    if(converted >= 360)
        converted -= 360;
    return (360*numRound) + converted;
}

/*Returns the current X pos of the spiral using some fun
    circle math.*/
double Spiral::getSpiralX(){
    double radius = angle * scale;
    double rad = ConvertAngle(angle) / 180 * 3.141592;
    return centerX + cos(rad) * radius;
}

/*Returns the current Y pos of the spiral using some fun
    circle math.*/
double Spiral::getSpiralY(){
    double radius = angle * scale;
    double rad = ConvertAngle(angle) / 180 * 3.141592;
    return centerY + sin(rad) * radius;
}

/*Returns the current angle of the spiral.*/
double Spiral::getSpiralAngle(){
    return angle;
}

/*Increments the angle of the spiral using the += op.*/
Spiral& Spiral::operator+=(double change){
    angle += change;
    return *this;
}




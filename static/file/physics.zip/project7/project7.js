// This function takes the translation and two rotation angles (in radians) as input arguments.
// The two rotations are applied around x and y axes.
// It returns the combined 4x4 transformation matrix as an array in column-major order.
// You can use the MatrixMult function defined in project5.html to multiply two 4x4 matrices in the same format.
function GetModelViewMatrix( translationX, translationY, translationZ, rotationX, rotationY )
{
	var rotX = [
		1, 0, 0, 0,
		0, Math.cos(rotationX), -Math.sin(rotationX), 0,
		0, Math.sin(rotationX), Math.cos(rotationX), 0,
		0, 0, 0, 1
	];
	var rotY = [
		Math.cos(rotationY), 0, Math.sin(rotationY), 0,
		0, 1, 0, 0,
		-Math.sin(rotationY	), 0, Math.cos(rotationY), 0,
		0, 0, 0, 1
	];
	var rotAll = MatrixMult(rotX, rotY);
	var trans = [
		1, 0, 0, 0,
		0, 1, 0, 0,
		0, 0, 1, 0,
		translationX, translationY, translationZ, 1
	];

	return MatrixMult(trans, rotAll);
}

class MeshDrawer
{
	// The constructor is a good place for taking care of the necessary initializations.
	constructor()
	{
		// Vertex Shader
		var vertexShader = /*glsl*/`
			attribute vec3 pos;
			attribute vec2 txc;
			attribute vec3 norm;

			uniform int swapFlag;
			uniform mat4 mvp;
			uniform mat4 mv;
			uniform mat3 n;
			varying vec2 texCoord;
			varying vec3 fn;
			varying vec3 vertPos;

			void main(){
				if(swapFlag == 1){
					gl_Position = mvp * vec4(pos.x, pos.z, pos.y, 1);
				} else{
					gl_Position = mvp * vec4(pos,1);
				}

				texCoord = txc;
				fn = n * pos;
				vertPos = vec3(mv * vec4(pos,1));
			}
		`;
		// Fragment Shader
		var fragmentShader = /*glsl*/`
			precision mediump float;

			uniform sampler2D tex;
			uniform int showFlag;
			uniform vec3 lightDir;
			uniform float shine;

			varying vec2 texCoord;
			varying vec3 fn;
			varying vec3 vertPos;

			void main(){
				vec4 I = vec4(1,1,1,1);
				vec4 ks = vec4(1,1,1,1);
				vec4 kd;
				vec4 ambientColor =  I * vec4(0.1,0.1,0.1,1.0);

				if(showFlag == 1){
					kd = texture2D(tex, texCoord);
				} 
				else{
					kd = vec4(1,1,1,1);
				}

				//given vectors
				vec3 n = normalize(fn);
				vec3 w = normalize(lightDir);
				vec3 v = normalize(-vertPos);

				//half vector
				vec3 h = normalize(w + v);

				//formula terms
				float theta = dot(n,w);
				float phi = dot(n,h);

				//formula
				gl_FragColor = I * max(0.0,theta) * (kd + ks * pow(max(0.0,phi),shine)) + ambientColor;
			}
				`;
		//Get locations
		this.prog = InitShaderProgram(vertexShader, fragmentShader);
		gl.useProgram(this.prog);
		this.pos = gl.getAttribLocation(this.prog, 'pos');
		this.txc = gl.getAttribLocation(this.prog, 'txc');
		this.norm = gl.getAttribLocation(this.prog, 'norm');
		this.mvp = gl.getUniformLocation(this.prog, 'mvp');
		this.mv = gl.getUniformLocation(this.prog, 'mv');
		this.n = gl.getUniformLocation(this.prog, 'n');
		this.tex = gl.getUniformLocation(this.prog, 'tex');
		this.swapFlag = gl.getUniformLocation(this.prog, 'swapFlag');
		this.showFlag = gl.getUniformLocation(this.prog, 'showFlag');
		this.lightDir = gl.getUniformLocation(this.prog, 'lightDir');
		this.shine = gl.getUniformLocation(this.prog, 'shine');
		//Create buffers
		this.posBuffer = gl.createBuffer();
		this.txcBuffer = gl.createBuffer();
		this.normBuffer = gl.createBuffer();
		//Create texture
		this.texture = gl.createTexture();
		//Make sure flags are set correctly
		this.showTexture(true);
	}
	
	// This method is called every time the user opens an OBJ file.
	// The arguments of this function is an array of 3D vertex positions,
	// an array of 2D texture coordinates, and an array of vertex normals.
	// Every item in these arrays is a floating point value, representing one
	// coordinate of the vertex position or texture coordinate.
	// Every three consecutive elements in the vertPos array forms one vertex
	// position and every three consecutive vertex positions form a triangle.
	// Similarly, every two consecutive elements in the texCoords array
	// form the texture coordinate of a vertex and every three consecutive 
	// elements in the normals array form a vertex normal.
	// Note that this method can be called multiple times.
	setMesh( vertPos, texCoords, normals )
	{
		this.numTriangles = vertPos.length / 3;

		gl.useProgram( this.prog );
		gl.bindBuffer( gl.ARRAY_BUFFER, this.posBuffer );
		gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertPos), gl.DYNAMIC_DRAW);
		gl.vertexAttribPointer( this.pos, 3, gl.FLOAT, false, 0, 0 );


		gl.bindBuffer(gl.ARRAY_BUFFER, this.txcBuffer);
		gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(texCoords), gl.DYNAMIC_DRAW);
		gl.vertexAttribPointer( this.txc, 2, gl.FLOAT, false, 0, 0 );
		gl.enableVertexAttribArray( this.txc );

		gl.bindBuffer(gl.ARRAY_BUFFER, this.normBuffer);
		gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(normals), gl.DYNAMIC_DRAW);
		gl.vertexAttribPointer( this.norms, 3, gl.FLOAT, false, 0, 0 );
		gl.enableVertexAttribArray( this.norms );
	}
	
	// This method is called when the user changes the state of the
	// "Swap Y-Z Axes" checkbox. 
	// The argument is a boolean that indicates if the checkbox is checked.
	swapYZ( swap )
	{
		gl.useProgram(this.prog);
		if(swap)lightIntensity
			gl.uniform1i(this.swapFlag, 0);
	}
	
	// This method is called to draw the triangular mesh.
	// The arguments are the model-view-projection transformation matrixMVP,
	// the model-view transformation matrixMV, the same matrix returned
	// by the GetModelViewProjection function above, and the normal
	// transformation matrix, which is the inverse-transpose of matrixMV.
	draw( matrixMVP, matrixMV, matrixNormal )
	{

		gl.useProgram(this.prog);
		gl.uniformMatrix4fv(this.mvp, 0, matrixMVP);
		gl.uniformMatrix4fv(this.mv, 0, matrixMV);
		gl.uniformMatrix3fv(this.n, 0, matrixNormal);

		gl.bindBuffer( gl.ARRAY_BUFFER, this.posBuffer );
		gl.vertexAttribPointer( this.pos, 3, gl.FLOAT, false, 0, 0 );
		gl.enableVertexAttribArray( this.pos );

		gl.bindBuffer( gl.ARRAY_BUFFER, this.txcBuffer );
		gl.vertexAttribPointer( this.txc, 2, gl.FLOAT, false, 0, 0 );
		gl.enableVertexAttribArray( this.txc );

		gl.drawArrays( gl.TRIANGLES, 0, this.numTriangles );
	}
	
	// This method is called to set the texture of the mesh.
	// The argument is an HTML IMG element containing the texture data.
	setTexture( img )
	{
		gl.useProgram(this.prog);
		gl.bindTexture(gl.TEXTURE_2D, this.texture);
		gl.texImage2D( gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, img );
		gl.generateMipmap(gl.TEXTURE_2D);
		gl.texParameteri(
			gl.TEXTURE_2D,
			gl.TEXTURE_MIN_FILTER,
			gl.LINEAR_MIPMAP_LINEAR
		);
		gl.activeTexture(gl.TEXTURE0);
		gl.bindTexture(gl.TEXTURE_2D, this.texture);
		gl.uniform1i(this.tex, 0);
	}
	
	// This method is called when the user changes the state of the
	// "Show Texture" checkbox. 
	// The argument is a boolean that indicates if the checkbox is checked.
	showTexture( show )
	{
		gl.useProgram(this.prog);
		if(show)
			gl.uniform1i(this.showFlag, 1);
		else
			gl.uniform1i(this.showFlag, 0);
	}
	
	// This method is called to set the incoming light direction
	setLightDir( x, y, z )
	{
		gl.useProgram(this.prog);
		gl.uniform3f(this.lightDir, x, y, z);
	}
	
	// This method is called to set the shininess of the material
	setShininess( shininess )
	{
		gl.useProgram(this.prog);
		gl.uniform1f(this.shine, shininess);
	}
}


// This function is called for every step of the simulation.
// Its job is to advance the simulation for the given time step duration dt.
// It updates the given positions and velocities.
function SimTimeStep( dt/*scalar*/, positions/*array*/, velocities/*array*/, springs/*array*/, stiffness/*scalar*/, damping/*scalar*/, particleMass/*scalar*/, gravity/*vec3*/, restitution/*scalar*/ )
{
	var forces = Array( positions.length ); // The total for per particle

	// [TO-DO] Compute the total force of each particle
	//add gravity
	forces.fill(gravity.mul(particleMass));
	//add each spring&damping force
	for(var i = 0; i < springs.length; i++){
		var spring = springs[i];

		// spring attributes
		var x0 = positions[spring.p0];
		var x1 = positions[spring.p1];
		var v0 = velocities[spring.p0]
		var v1 = velocities[spring.p1]; 

		// caculate spring force
		var l = x1.sub(x0).len();
		var dhat = x1.sub(x0).div(l); 
		var springForce = dhat.mul(stiffness * (l - spring.rest));

		// caculate damping force 
		var ldot = v1.sub(v0).dot(dhat);
		var dampingForce = dhat.mul(ldot).mul(damping);

		// add spring force
		forces[spring.p0] = forces[spring.p0].add(springForce); 
		forces[spring.p1] = forces[spring.p1].add(springForce.mul(-1.0));

		// add damping force 
		forces[spring.p0] = forces[spring.p0].add(dampingForce); 
		forces[spring.p1] = forces[spring.p1].add(dampingForce.mul(-1.0));
	}
	// [TO-DO] Update positions and velocities
	for(var i = 0; i < forces.length; i++){
		var accel = forces[i].div(particleMass);
		velocities[i].inc(accel.mul(dt));
		positions[i].inc(velocities[i].mul(dt));
	}
	// [TO-DO] Handle collisions
	for(var i = 0; i < positions.length; i++){
		var p = positions[i];
		//check X-axis
		if(p.x >= 1.0){
			var h = Math.abs(positions[i].x) - 1.0; 
			positions[i].x -= h + (h * restitution);
			velocities[i].x = velocities[i].x * (-1.0 * restitution);
		} 
		else if(p.x <= -1.0){
			var h = Math.abs(positions[i].x) - 1.0; 
			positions[i].x += h + (h * restitution);
			velocities[i].x = velocities[i].x * (-1.0 * restitution);
		}
		//check Y-axis
		if(p.y >= 1.0){
			var h = Math.abs(positions[i].y) - 1.0; 
			positions[i].y -= h + (h * restitution);
			velocities[i].y = velocities[i].y * (-1.0 * restitution);
		} 
		else if(p.y <= -1.0){
			var h = Math.abs(positions[i].y) - 1.0; 
			positions[i].y += h + (h * restitution);
			velocities[i].y = velocities[i].y * (-1.0 * restitution);
		}
		//check Z-axis
		if(p.z >= 1.0){
			var h = Math.abs(positions[i].z) - 1.0; 
			positions[i].z -= h + (h * restitution);
			velocities[i].z = velocities[i].z * (-1.0 * restitution);
		} 
		else if(p.z <= -1.0){
			var h = Math.abs(positions[i].z) - 1.0; 
			positions[i].z += h + (h * restitution);
			velocities[i].z = velocities[i].z * (-1.0 * restitution);
		}
	}
}


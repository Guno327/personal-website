/*
 * mm.c - An attempt at an explicit free list allocator
 * 
 * In this allocator we use an doubly-linked explicit
 * free list to represent our free blocks. It uses an
 * 8-byte header and footer for both free and allocated
 * blocks. This allocator also supports coalescing, 
 * free block splitting, and realeasing pages on free.
 * It makes a best attempt to grow the heap twice as much
 * as the last time it grew, up until a limit of 32 pages.
 *
 * Gunnar Hovik - U1357887
 */
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <unistd.h>
#include <string.h>
#include "mm.h"
#include "memlib.h"

/*tyfeps*/
typedef size_t block_header;
typedef size_t block_footer;
typedef struct node {
  struct node* next;
  struct node* prev;
} node;

/*global vars*/
node* free_list;
size_t pages_in_use;

/*consts*/
#define ALIGNMENT 16
#define MIN_CHUNK_UNMAP 16
#define MAX_PAGES_PER_CHUNK 32
#define WSIZE 8
#define DSIZE 16

/*alignment macros*/
#define ALIGN(size) (((size) + (ALIGNMENT-1)) & ~(ALIGNMENT-1))
#define PAGE_ALIGN(size) (((size) + (mem_pagesize()-1)) & ~(mem_pagesize()-1))

/*math macros*/
#define MAX(x, y) ((x) > (y)? (x) : (y))
#define MIN(x, y) ((x) < (y)? (x) : (y))

/*heap macros*/
#define BLOCK_OVERHEAD (sizeof(block_header)+sizeof(block_footer))
#define CHUNK_OVERHEAD (sizeof(node) + BLOCK_OVERHEAD + sizeof(block_header))
#define HDRP(bp) ((void *)(bp) - sizeof(block_header))
#define FTRP(bp) ((void *)(bp)+GET_SIZE(HDRP(bp))-BLOCK_OVERHEAD)
#define NEXT_BLKP(bp) ((void *)(bp) + GET_SIZE(HDRP(bp)))
#define PREV_BLKP(bp) ((void *)(bp) - GET_SIZE((char *)(bp)-BLOCK_OVERHEAD))
#define GET(p) (*(size_t *)(p))
#define PUT(p, val) (*(size_t *)(p) = (val))
#define PACK(size, alloc) ((size) | (alloc))
#define GET_ALLOC(p) (GET(p) & 0x1)
#define GET_SIZE(p) (GET(p) & ~0xF)

/*helper methods*/
static void* coalesce(void* bp);
static void set_allocated(void* bp, size_t size);
static void* map_chunk(size_t size);
static void unmap_chunk(void* fp);
static void remove_node(node* node);
static void add_node(node* bp);

/*Sets up the allocator*/
int mm_init(void)
{
  //vars
  free_list = NULL;
  pages_in_use = 0;
  
  //start with just 1 page
  map_chunk(mem_pagesize() * 1);

  return 0;
}

/*Allocates memory region of size and return pointer to payload*/
void *mm_malloc(size_t size)
{
  size = ALIGN(MAX(size, sizeof(node)) + BLOCK_OVERHEAD);
  node* ptr = free_list;

  //no use checking if free_list is empty
  if(free_list){
    while(ptr != NULL){
      if( GET_SIZE(HDRP(ptr)) >= size)
          break;
      ptr = ptr->next;
    }
  }

  //free block found
  if(ptr){
    set_allocated(ptr, size);
    return ptr;
  }

  //Alloc new block
  ptr = map_chunk(size);
  set_allocated(ptr, size);

  return ptr;
}

/*Frees memory region whose payload is at ptr*/
void mm_free(void* ptr)
{
  size_t size = GET_SIZE(HDRP(ptr));
  PUT(HDRP(ptr), PACK(size,0));
  ptr = coalesce(ptr);

  //unmap chunk if empty and we have enough pages already
  if(pages_in_use > MIN_CHUNK_UNMAP)
    unmap_chunk(ptr);
}

static void* coalesce(void* ptr){
  size_t prev_alloc = GET_ALLOC(HDRP(PREV_BLKP(ptr)));
  size_t next_alloc = GET_ALLOC(HDRP(NEXT_BLKP(ptr)));
  size_t size = GET_SIZE(HDRP(ptr));

  //no free neighbors
  if(prev_alloc && next_alloc){
    add_node((node*)ptr);
  }

  //free to right
  else if(prev_alloc && !next_alloc){
    remove_node((node*)NEXT_BLKP(ptr));
    add_node((node*)ptr);
    size += GET_SIZE(HDRP(NEXT_BLKP(ptr)));
    PUT(HDRP(ptr), PACK(size,0));
    PUT(FTRP(ptr), PACK(size, 0));
  }

  //free to left
  else if(!prev_alloc && next_alloc){
    size += GET_SIZE(HDRP(PREV_BLKP(ptr)));
    PUT(FTRP(ptr), PACK(size, 0));
    PUT(HDRP(PREV_BLKP(ptr)), PACK(size, 0));
    ptr = PREV_BLKP(ptr);
  }


  //free both sides
  else{
    remove_node((node*)NEXT_BLKP(ptr));
    size += (GET_SIZE(HDRP(PREV_BLKP(ptr))) + GET_SIZE(HDRP(NEXT_BLKP(ptr))));
    PUT(FTRP(NEXT_BLKP(ptr)), PACK(size, 0));
    PUT(HDRP(PREV_BLKP(ptr)), PACK(size, 0));
    ptr = PREV_BLKP(ptr);
  }

  return ptr;
}

/*Sets memory region starting at ptr of size bytes to allocated.
* Attempt to split the block into an allocated and free block
* if possible*/
static void set_allocated(void* ptr, size_t size){
  //if remaining size big enough for free block, split
  size_t block_size = GET_SIZE(HDRP(ptr));
  size_t rem_size = block_size - size;
  if(rem_size > ALIGN(sizeof(node) + BLOCK_OVERHEAD)){
    remove_node(ptr);

    //alloc front
    PUT(HDRP(ptr), PACK(size, 1));
    PUT(FTRP(ptr), PACK(size, 1));

    //new free node in back
    PUT(HDRP(NEXT_BLKP(ptr)), PACK(rem_size, 0));
    PUT(FTRP(NEXT_BLKP(ptr)), PACK(rem_size, 0));
    add_node((node*)NEXT_BLKP(ptr));
  }

  //otherwise alloc who block
  else{
    PUT(HDRP(ptr), PACK(block_size, 1));
    remove_node((void*)ptr);
  }
}

/*Maps a new chunk of size bytes in memory*/
static void* map_chunk(size_t size){
  //we want to at least double the heap
  size_t pages = PAGE_ALIGN(size) / mem_pagesize();
  pages = MAX(pages, pages_in_use);
  //but we don't want to exceed Max because then we will run out of mem
  pages = MIN(pages, MAX_PAGES_PER_CHUNK);

  //store for freeing check
  pages_in_use += pages;
  size = pages * mem_pagesize();

  void* new_chunk = mem_map(size); 
  if(new_chunk == NULL)
    return NULL;
  
  //prolouge
  void* pro_bp = new_chunk + BLOCK_OVERHEAD;
  PUT(HDRP(pro_bp), PACK(BLOCK_OVERHEAD, 1));
  PUT(FTRP(pro_bp), PACK(BLOCK_OVERHEAD, 1));
  //epilouge
  void * epi_bp = new_chunk + size;
  PUT(HDRP(epi_bp), PACK(0,1));

  //initial empty block
  size = size - 2*BLOCK_OVERHEAD;
  void* bp = new_chunk + 2*BLOCK_OVERHEAD;
  PUT(HDRP(bp), PACK(size, 0));
  PUT(FTRP(bp), PACK(size,0));

  // Add free block to the explicit free list
  add_node((node*)bp);

  return bp;
}

/*Attempts to return a chunk of memory whose payload
* begins at ptr to the OS. Only possible if payload at
* ptr is the only block in this chunk of memory.*/
static void unmap_chunk(void* ptr){
  if(ptr == NULL)
    return;

  //check for prolouge
  if(GET_SIZE(HDRP(PREV_BLKP(ptr))) != BLOCK_OVERHEAD)
    return;

  //check for epilouge
  if(GET_SIZE(HDRP(NEXT_BLKP(ptr))) != 0)
    return;

  //free
  size_t size = GET_SIZE(HDRP(ptr)) + 2*BLOCK_OVERHEAD;
  remove_node(ptr);
  ptr -= 2*BLOCK_OVERHEAD;
  mem_unmap(ptr, size);
  pages_in_use -= (size / mem_pagesize());
}

/*Removes a node from our doubly-linked list
* of free blocks*/
static void remove_node(node* n){
  //first node
  if(n == free_list){
    if(n->next){
      n->next->prev = NULL;
      free_list = n->next;
    }
    //only node
    else
      free_list = NULL;
  }

  else{
    //middle node
    if(n->prev && n->next){
      n->prev->next = n->next;
      n->next->prev = n->prev;
    }
    //end node
    else if(n->prev)
      n->prev->next = NULL;
  }
}

/*Adds a node to our doubly-linked list
* of free blocks*/
static void add_node(node* n){
  //not first
  if(free_list){
    free_list->prev = n;
    n->next = free_list;
  }

  //first node
  else{
    n->next = NULL;
  }

  n->prev = NULL;
  free_list = n;
}
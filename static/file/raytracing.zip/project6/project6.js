var raytraceFS = /*glsl*/`
struct Ray {
	vec3 pos;
	vec3 dir;
};

struct Material {
	vec3  k_d;	// diffuse coefficient
	vec3  k_s;	// specular coefficient
	float n;	// specular exponent
};

struct Sphere {
	vec3     center;
	float    radius;
	Material mtl;
};

struct Light {
	vec3 position;
	vec3 intensity;
};

struct HitInfo {
	float    t;
	vec3     position;
	vec3     normal;
	Material mtl;
};

uniform Sphere spheres[ NUM_SPHERES ];
uniform Light  lights [ NUM_LIGHTS  ];
uniform samplerCube envMap;
uniform int bounceLimit;

bool IntersectRay( inout HitInfo hit, Ray ray);

// Shades the given point and returns the computed color.
vec3 Shade( Material mtl, vec3 position, vec3 normal, vec3 view )
{
	vec3 color = vec3(0,0,0);
	for ( int i=0; i<NUM_LIGHTS; ++i ) {
		//Check if shadowed
		Ray r;
		r.dir = normalize(lights[i].position - position);
		r.pos = position;
		HitInfo hit;
		bool intersect = IntersectRay(hit,r);

		//ignore if shadowed
		if(intersect)
			continue;

		//if not shadowed, blinn model
		//diffuse
		normal = normalize(normal);
		vec3 lightDir = normalize((lights[i].position - position));
		float cosTheta = dot(normal, lightDir);
		vec3 diffuse = mtl.k_d * lights[i].intensity * max(0.0, cosTheta); 
			
		//specular
		vec3 halfAngle = normalize(view + lightDir);
		vec3 specular = mtl.k_s * lights[i].intensity * pow(max(0.0, dot(normal, halfAngle)),mtl.n);
		
		color += diffuse + specular;
	}
	return color;
}

// Intersects the given ray with all spheres in the scene
// and updates the given HitInfo using the information of the sphere
// that first intersects with the ray.
// Returns true if an intersection is found.
bool IntersectRay( inout HitInfo hit, Ray ray )
{
	hit.t = 1e30;
	bool foundHit = false;

	for ( int i=0; i<NUM_SPHERES; ++i ) {//hit
		Sphere s = spheres[i];

		//math vars
		vec3 d = ray.dir;
		vec3 p = ray.pos;
		vec3 pc = p - s.center ;

		//math
		float a = dot(d,d);
		float b = dot((2.0*d),pc);
		float c = (dot(pc,pc) - pow(s.radius,2.0));
		float delta = (pow(b,2.0) - (4.0*a*c));
		
		//found hit
		if(delta >= 0.0){
			float t0 = ((-b) - sqrt(delta)) / (2.0*a);
			if(t0 > 0.0 && t0 <= hit.t){
				foundHit = true;
				hit.t = t0;
				hit.position = ray.pos + (ray.dir * t0) ; 
				hit.normal = normalize((hit.position - s.center)/s.radius);
				hit.mtl = s.mtl;
			}
		}
	}
	return foundHit;
}

// Given a ray, returns the shaded color where the ray intersects a sphere.
// If the ray does not hit a sphere, returns the environment color.
vec4 RayTracer( Ray ray )
{
	HitInfo hit;
	if ( IntersectRay( hit, ray ) ) {
		vec3 view = normalize( -ray.dir );
		vec3 clr = Shade( hit.mtl, hit.position, hit.normal, view );
		
		// Compute reflections
		vec3 k_s = hit.mtl.k_s;
		for ( int bounce=0; bounce<MAX_BOUNCES; ++bounce ) {
			if ( bounce >= bounceLimit ) break;
			if ( hit.mtl.k_s.r + hit.mtl.k_s.g + hit.mtl.k_s.b <= 0.0 ) break;
			
			Ray r;	// this is the reflection ray
			HitInfo h;	// reflection hit info
			
			r.dir = normalize(reflect(ray.dir,hit.normal));
			r.pos = hit.position;
			
			if ( IntersectRay( h, r ) ) {
				clr += k_s * Shade( h.mtl, h.position, h.normal, view );
				
				hit = h;
				ray = r;
				k_s *= h.mtl.k_s;
			} else {
				// The refleciton ray did not intersect with anything,
				// so we are using the environment color
				clr += k_s * textureCube( envMap, r.dir.xzy ).rgb;
				break;	// no more reflections
			}
		}
		return vec4( clr, 1 );	// return the accumulated color, including the reflections
	} else {
		return vec4( textureCube( envMap, ray.dir.xzy ).rgb, 1 );	// return the environment color
	}
}
`;
/*
 * friendlist.c - Completed assignment by Gunnar Hovik.
 *
 * Based on:
 *  tiny.c - A simple, iterative HTTP/1.0 Web server that uses the 
 *      GET method to serve static and dynamic content.
 *   Tiny Web server
 *   Dave O'Hallaron
 *   Carnegie Mellon University
 */
#include "csapp.h"
#include "dictionary.h"
#include "more_string.h"
//given
static void doit(int fd);
static dictionary_t *read_requesthdrs(rio_t *rp);
static void read_postquery(rio_t *rp, dictionary_t *headers, dictionary_t *d);
static void clienterror(int fd, char *cause, char *errnum, 
                        char *shortmsg, char *longmsg);
static void serve_request(int fd, char *body);
//added
static void befriend(int fd, dictionary_t *query);
static void unfriend(int fd, dictionary_t *query);
static void friends(int fd, dictionary_t *query);
static void introduce(int fd, dictionary_t *query);
static void *work(void *fd);
//vars
static dictionary_t *friend_list_global;
static void* alloc_flag;
static pthread_mutex_t mutex;

int main(int argc, char **argv) {
  int listenfd, connfd;
  char hostname[MAXLINE], port[MAXLINE];
  socklen_t clientlen;
  struct sockaddr_storage clientaddr;

  /* Check command line args */
  if (argc != 2) {
    fprintf(stderr, "usage: %s <port>\n", argv[0]);
    exit(1);
  }

  friend_list_global = make_dictionary(COMPARE_CASE_INSENS, free);
  alloc_flag = malloc(1);
  pthread_mutex_init(&mutex, NULL);

  listenfd = Open_listenfd(argv[1]);

  /* Don't kill the server if there's an error, because
     we want to survive errors due to a client. But we
     do want to report errors. */
  exit_on_error(0);

  /* Also, don't stop on broken connections: */
  Signal(SIGPIPE, SIG_IGN);

  while (1) {
    clientlen = sizeof(clientaddr);
    connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen);
    if (connfd >= 0) {
      Getnameinfo((SA *) &clientaddr, clientlen, hostname, MAXLINE, 
                  port, MAXLINE, 0);
      printf("Accepted connection from (%s, %s)\n", hostname, port);
      int *fd;
      pthread_t th;
      fd = malloc(sizeof(int));
      *fd = connfd;
      pthread_create(&th, NULL, work, fd);
      pthread_detach(th);
    }
  }
}

/*thread target program to do work*/
void *work(void *fd)
{
 doit(*(int*)fd);
 Close(*(int*)fd);
 free(fd);
 return NULL;
}

/*
 * doit - handle one HTTP request/response transaction
 */
void doit(int fd) {
  char buf[MAXLINE], *method, *uri, *version;
  rio_t rio;
  dictionary_t *headers, *query;

  /* Read request line and headers */
  Rio_readinitb(&rio, fd);
  if (Rio_readlineb(&rio, buf, MAXLINE) <= 0)
    return;
  printf("%s", buf);
  
  if (!parse_request_line(buf, &method, &uri, &version)) {
    clienterror(fd, method, "400", "Bad Request",
                "Friendlist did not recognize the request");
  } else {
    if (strcasecmp(version, "HTTP/1.0")
        && strcasecmp(version, "HTTP/1.1")) {
      clienterror(fd, version, "501", "Not Implemented",
                  "Friendlist does not implement that version");
    } else if (strcasecmp(method, "GET")
               && strcasecmp(method, "POST")) {
      clienterror(fd, method, "501", "Not Implemented",
                  "Friendlist does not implement that method");
    } else {
      headers = read_requesthdrs(&rio);

      /* Parse all query arguments into a dictionary */
      query = make_dictionary(COMPARE_CASE_SENS, free);
      parse_uriquery(uri, query);
      if (!strcasecmp(method, "POST"))
        read_postquery(&rio, headers, query);

      /* For debugging, print the dictionary */
      //print_stringdictionary(query);

      //get the path
      char** working = split_string(buf, ' ');
      working = split_string(working[1], '?');
      char* path = working[0];

      //call correct function
      if(!strcasecmp(path, "/unfriend"))
        unfriend(fd, query); 
      else if(!strcasecmp(path, "/befriend"))
        befriend(fd, query);
      else if(!strcasecmp(path, "/friends"))
        friends(fd, query);
      else if(!strcasecmp(path, "/introduce"))
        introduce(fd, query);
      else
        clienterror(fd, path, "501", "Not Implemented",
                  "Friendlist does not implement that command");

      /* Clean up */
      free(working);  
      free_dictionary(query);
      free_dictionary(headers);
    }

    /* Clean up status line */
    free(method);
    free(uri);
    free(version);
  }
}

/*implements the /befriend command*/
static void befriend(int fd, dictionary_t *query){
  //get user and friends
  char* user = dictionary_get(query, "user");
  char* friends_raw = dictionary_get(query, "friends");

  if(friends_raw == NULL){
    clienterror(fd, "friends", "400", "Friends not Specified",
                  "A friends query is required for this command");
    return;
  }
  if(user == NULL){
    clienterror(fd, "user", "400", "User not Specified",
                  "A user query is required for this command");
    return;
  }
    
  //split friends
  char** new_friends = split_string(friends_raw, '\n');

  //make sure user entry exist
  pthread_mutex_lock(&mutex);
  dictionary_t *user_list = dictionary_get(friend_list_global, user);
  if(user_list == NULL){
    user_list = make_dictionary(COMPARE_CASE_INSENS, NULL);
    dictionary_set(friend_list_global, user, user_list);
  }

  //add friends (if not already there)
  int i;
  for(i = 0; new_friends[i] != NULL; i++){
    char* new_friend = new_friends[i];
    //see if already friend, if so we should do nothing
    if(dictionary_get(user_list, new_friend) != NULL)
      continue;
    //add friend, if not self
    if(strcasecmp(user, new_friend))
      dictionary_set(user_list, new_friend, alloc_flag);
    else
      continue;
    //add user to friend's list (make if doesn't exist)
    dictionary_t *other_list = dictionary_get(friend_list_global,new_friend);
    if(other_list == NULL){
      other_list = make_dictionary(COMPARE_CASE_INSENS, NULL);
      dictionary_set(friend_list_global, new_friend, other_list);
    }
    dictionary_set(other_list, user, alloc_flag);
    free(new_friends[i]);
  }
  pthread_mutex_unlock(&mutex);

  //reply with list
  friends(fd, query);
  free(new_friends);
}

/*implements the /unfriend command*/
static void unfriend(int fd, dictionary_t *query){
  //get user and friends
  char* user = dictionary_get(query, "user");
  char* friends_raw = dictionary_get(query, "friends");

  if(friends_raw == NULL){
    clienterror(fd, "friends", "400", "Friends not Specified",
                  "A friends query is required for this command");
    return;
  }
  if(user == NULL){
    clienterror(fd, "user", "400", "User not Specified",
                  "A user query is required for this command");
    return;
  }

  //split friends
  char** old_friends = split_string(friends_raw, '\n');

  //make sure user entry exist
  pthread_mutex_lock(&mutex);
  dictionary_t *user_list = dictionary_get(friend_list_global, user);
  if(user_list == NULL){
    clienterror(fd, user, "400", "User not found",
                  "The server does not have record of this user");
    free(old_friends);
    pthread_mutex_unlock(&mutex);
    return;
  }

  //remove friends
  int i;
  for(i = 0; old_friends[i] != NULL; i++){
    //remove from user list
    dictionary_remove(user_list,old_friends[i]);
    //remove from other list
    dictionary_t* other_list = dictionary_get(friend_list_global,old_friends[i]);
    if(other_list != NULL)
      dictionary_remove(other_list,user);
    free(old_friends[i]);
  }
  pthread_mutex_unlock(&mutex);

  //reply with list
  friends(fd, query);
  free(old_friends);
}

/*impelemts the /friends command*/
static void friends(int fd, dictionary_t *query){
  //get user and list
  char* user = dictionary_get(query, "user");
  if(user == NULL){
    clienterror(fd, "user", "400", "Missing user query",
      "User must be specified as a query");
    return;
  }
  pthread_mutex_lock(&mutex);
  dictionary_t *friend_list_raw = dictionary_get(friend_list_global, user);
  if(friend_list_raw == NULL){
    serve_request(fd, "");
    pthread_mutex_unlock(&mutex);
    return;
  }
  const char** friend_list = dictionary_keys(friend_list_raw);

  //compile list
  char* body = join_strings(friend_list, '\n');
  pthread_mutex_unlock(&mutex);
    
  //send list
  serve_request(fd, body);
  free(body);
  free(friend_list);
}

/*implements the /introduce command*/
static void introduce(int fd, dictionary_t *query){
  //get and check all values
  char* user = dictionary_get(query, "user");
  char* friend = dictionary_get(query, "friend");
  char* host = dictionary_get(query, "host");
  char* port = dictionary_get(query, "port");

  if(user == NULL){
    clienterror(fd, "user", "400", "Missing user query",
      "User must be specified as a query");
    return;
  }
  if(friend == NULL){
    clienterror(fd, "friend", "400", "Missing friend query",
      "Friend must be specified as a query");
    return;
  }
  if(host == NULL){
    clienterror(fd, "host", "400", "Missing host query",
      "Host must be specified as a query");
    return;
  }
  if(port == NULL){
    clienterror(fd, "port", "400", "Missing port query",
      "Port must be specified as a query");
    return;
  }
  
  //Make connection and query
  char send_buf[MAXBUF];
  int connfd = Open_clientfd(host, port);
  sprintf(send_buf, "GET /friends?user=%s HTTP/1.1\r\n\r\n", query_encode(friend));
  Rio_writen(connfd, send_buf, strlen(send_buf));
  char status_buf[MAXLINE];
  rio_t rio;
  Rio_readinitb(&rio, connfd);

  //check response
  if(Rio_readlineb(&rio, status_buf, MAXLINE) <= 0)
  {
    clienterror(fd, "host:port", "400", "Bad Request",
      "Can't read from requested server.");
      return;
  }

  char *version, *status, *desc;
  if(!parse_status_line(status_buf, &version, &status, &desc)){
    clienterror(fd, "host:port", "400", "Bad Request",
      "Malformed server response");
  }
  if (strcasecmp(version, "HTTP/1.0") && strcasecmp(version, "HTTP/1.1")) {
    clienterror(fd, version, "501", "Not Implemented",
      "Friendlist does not implement that version");
  }
  if (strcasecmp(status, "200") && strcasecmp(desc, "OK")) {
    clienterror(fd, status, "400", "Bad Request",
      "Target server responded not ok");
  }

  //get list
  dictionary_t *headers = read_requesthdrs(&rio);
  char *len_raw = dictionary_get(headers, "Content-length");
  
  int len = 0;
  if(len_raw != NULL)
    len = atoi(len_raw);
  char rec_buf[len];
  
  if(len <= 0)
  {
    clienterror(fd, "header", "400", "Bad Request",
    "No friends recieved");
  }

  Rio_readnb(&rio, rec_buf, len);
  rec_buf[len] = 0;

  //add friends
  dictionary_t* query_befriend = make_dictionary(COMPARE_CASE_INSENS, NULL);
  dictionary_set(query_befriend, "user", user);
  dictionary_set(query_befriend, "friends", rec_buf);
  befriend(fd, query_befriend);

  //cleanup
  free(version);
  free(status);
  free(desc);
  free_dictionary(headers);
  //free_dictionary(query_befriend);
  close(connfd);
}

/*
 * read_requesthdrs - read HTTP request headers
 */
dictionary_t *read_requesthdrs(rio_t *rp) {
  char buf[MAXLINE];
  dictionary_t *d = make_dictionary(COMPARE_CASE_INSENS, free);

  Rio_readlineb(rp, buf, MAXLINE);
  printf("%s", buf);
  while(strcmp(buf, "\r\n")) {
    Rio_readlineb(rp, buf, MAXLINE);
    printf("%s", buf);
    parse_header_line(buf, d);
  }
  
  return d;
}

void read_postquery(rio_t *rp, dictionary_t *headers, dictionary_t *dest) {
  char *len_str, *type, *buffer;
  int len;
  
  len_str = dictionary_get(headers, "Content-Length");
  len = (len_str ? atoi(len_str) : 0);

  type = dictionary_get(headers, "Content-Type");
  
  buffer = malloc(len+1);
  Rio_readnb(rp, buffer, len);
  buffer[len] = 0;

  if (!strcasecmp(type, "application/x-www-form-urlencoded")) {
    parse_query(buffer, dest);
  }

  free(buffer);
}

static char *ok_header(size_t len, const char *content_type) {
  char *len_str, *header;
  
  header = append_strings("HTTP/1.0 200 OK\r\n",
                          "Server: Friendlist Web Server\r\n",
                          "Connection: close\r\n",
                          "Content-length: ", len_str = to_string(len), "\r\n",
                          "Content-type: ", content_type, "\r\n\r\n",
                          NULL);
  free(len_str);

  return header;
}

/*
 * serve_request - example request handler
 */
static void serve_request(int fd, char *body) {
  size_t len;
  char *header;

  len = strlen(body);

  /* Send response headers to client */
  header = ok_header(len, "text/html; charset=utf-8");
  Rio_writen(fd, header, strlen(header));
  printf("Response headers:\n");
  printf("%s", header);

  free(header);

  /* Send response body to client */
  Rio_writen(fd, body, len);
}

/*
 * clienterror - returns an error message to the client
 */
void clienterror(int fd, char *cause, char *errnum, 
		 char *shortmsg, char *longmsg) {
  size_t len;
  char *header, *body, *len_str;

  body = append_strings("<html><title>Friendlist Error</title>",
                        "<body bgcolor=""ffffff"">\r\n",
                        errnum, " ", shortmsg,
                        "<p>", longmsg, ": ", cause,
                        "<hr><em>Friendlist Server</em>\r\n",
                        NULL);
  len = strlen(body);

  /* Print the HTTP response */
  header = append_strings("HTTP/1.0 ", errnum, " ", shortmsg, "\r\n",
                          "Content-type: text/html; charset=utf-8\r\n",
                          "Content-length: ", len_str = to_string(len), "\r\n\r\n",
                          NULL);
  free(len_str);
  
  Rio_writen(fd, header, strlen(header));
  Rio_writen(fd, body, len);

  free(header);
  free(body);
}

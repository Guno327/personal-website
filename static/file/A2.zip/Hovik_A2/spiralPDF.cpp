#include "Spiral.h"
#include "HaruPDF.h"
#include "iostream"
#include <math.h>
#include <string.h>
/*Example class using the Spiral and HaruPDF classes*/

/*Main method, creates a pdf that contains a spiral of text
    provided by arguments.*/
int main(int argc, char **argv){
    //Make sure text was provided
    if(argc < 2){
        std::cout << "No Sample Text Provided." << std::endl;
        return 1;
    }
    //Find out how much text there is
    int len = 0;
    for(len; len < 256; len++){
        if(argv[1][len] == '\0')
            break;
    }

    Spiral theSpiral {200, 350, 270, 0.2};
    HaruPDF thePDF {};
    for(int i = 0; i < len; i++){
        //Calculate values needed to update matrix
        double a,b,c,d;
        double rad1 = (theSpiral.ConvertAngle(theSpiral.getSpiralAngle()) - 90) / 180 * 3.141592;
        a = cos(rad1);
        b = sin(rad1);
        c = -sin(rad1);
        d = cos(rad1);
        //update matrix
        thePDF.SetRotationMatrix(a, b, c, d, theSpiral.getSpiralX(), theSpiral.getSpiralY());
        //Add next character
        thePDF.AddChar(argv[1][i]);
        //Progress spiral
        double amount = sqrt(i)*2;
        if(theSpiral.getSpiralAngle() < 1000)
            amount += 20;
        theSpiral += amount;
    }
    //Finish up PDF and make the file.
    char fname[256];
    strcpy (fname, argv[0]);
    strcat (fname, ".pdf");
    thePDF.CreateFile(fname);
    return 0;
}
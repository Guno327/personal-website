/*Header file for a class that does the math an calculations to create
    a spiral*/
class Spiral{
    double angle, centerX, centerY, scale;
    public:
    Spiral(double centerX, double centerY, double startAngle, double loopScale);
    Spiral& operator+=(double change);
    double ConvertAngle(double angle);
    double getSpiralX();
    double getSpiralY();
    double getSpiralAngle();
};
